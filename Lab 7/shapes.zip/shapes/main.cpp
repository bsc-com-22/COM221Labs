#include <iostream>
#include "Area.h"
#include "Circle.h"
#include "Triangle.h"
#include "Square.h"
using namespace std;
using namespace shapes;

int main(){
    float sideLength, base, height, radius;


    cout << "Square" << endl;
    cout << "\nEnter the side length for the square: " << endl;
    cin >> sideLength;
    cout << "The area of a square with the side length " << sq.getSideLength() <<
    " is " << Area::getSquareArea(sq) << endl;
    sq.setSideLength(newSideLength);
    sq.getSquareArea();
    Square sq(sideLength);

    cout << "Triangle" << endl;
    cout << "\nEnter the base: " << endl;
    cin >>  base;
    cout << "\nEnter the height: " << endl;
    cin >> height;
    cout << "The area of a triangle with the base " << tri.getBase() <<
    " and height " << tri.getHeight() << " is " << Area::getTriangleArea(tri) << endl;
    tri.setBase(newBase);
    tri.setHeight(newHeight);
    Triangle tri(base, height);

    cout << "Circle" << endl;
    cout << "\nEnter the radius: " << endl;
    cin >> radius;
    cout << "The area of a square with the side length " << cir.getRadius() <<
    " is " << Area::getCircleArea(cir) << endl;
    cir.setRadius(newSideLength);
    sq.getCircleArea();
    Circle cir(radius);

    return 0;
}