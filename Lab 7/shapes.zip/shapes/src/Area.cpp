#include "Area.h"
namespace shapes{
    float Area::getTriangleArea(const Triangle& t){
        return 0.5 * t.getBase() * t.getHeight();
    }
    float Area::getCircleArea(const Circle& c){
        return 3.14195 * c.getRadius() * c.getRadius();
    }
    float Area::getSquareArea(const Square& s){
        return s.getSideLength() * s.getSideLength();
    }
}