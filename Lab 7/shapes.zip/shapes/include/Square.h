namespace shapes{
    class Square{
        private:
        float sideLength;

        Square();
        ~Square();
        void setSideLength(float newSideLength);
        float getSideLength() const;
    };
}