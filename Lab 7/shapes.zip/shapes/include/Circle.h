namespace shapes{
    class Circle{
        private:
        float radius;
        Circle();
        ~Circle();
        void setRadius(float newRadius);
        float getRadius() const;
    };
}