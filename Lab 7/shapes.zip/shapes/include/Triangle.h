namespace shapes{
    class Triangle{
        private:
        float base;
        float height;
        
        Triangle();
        ~Triangle();
        void setBase(float newBase);
        void setHeight(float newHeight);
        float getBase() const;
        float getHeight() const;
    };
    
}